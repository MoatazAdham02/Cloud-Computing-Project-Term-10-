const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");

const app = express();

// MIDDLEWARE
app.use(cors());
app.use(express.json());

// MYSQL CONNECTION
const db = mysql.createConnection({
  host: "fitness-db.cd9ny2wbkgd9.us-east-1.rds.amazonaws.com",
  user: "root",
  password: "moataz2026",
  database: "fitness_tracker",
});

// CONNECT DATABASE
db.connect((err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("MySQL Connected");
  }
});

// =========================
// REGISTER USER
// =========================

app.post("/register", (req, res) => {

  const { name, email, password } = req.body;

  const sql =
    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";

  db.query(
    sql,
    [name, email, password],
    (err, result) => {

      if (err) {
        res.status(500).send(err);
      } else {
        res.send("User Registered");
      }

    }
  );
});

// =========================
// LOGIN USER
// =========================

app.post("/login", (req, res) => {

  const { email, password } = req.body;

  const sql =
    "SELECT * FROM users WHERE email = ? AND password = ?";

  db.query(
    sql,
    [email, password],
    (err, result) => {

      if (err) {
        res.status(500).send(err);
      } else {

        if (result.length > 0) {
          res.send(result);
        } else {
          res.status(401).send("Invalid Credentials");
        }

      }

    }
  );
});

// =========================
// GET ALL WORKOUTS
// =========================

app.get("/workouts", (req, res) => {

  const sql =
    "SELECT * FROM workouts ORDER BY id DESC";

  db.query(sql, (err, result) => {

    if (err) {
      res.status(500).send(err);
    } else {
      res.send(result);
    }

  });
});

// =========================
// ADD WORKOUT
// =========================

app.post("/workouts", (req, res) => {

  const {
    workout,
    duration,
    calories,
    date,
  } = req.body;

  const sql =
    "INSERT INTO workouts (workout, duration, calories, date) VALUES (?, ?, ?, ?)";

  db.query(
    sql,
    [workout, duration, calories, date],
    (err, result) => {

      if (err) {
        res.status(500).send(err);
      } else {
        res.send("Workout Added");
      }

    }
  );
});

// =========================
// UPDATE WORKOUT
// =========================

app.put("/workouts/:id", (req, res) => {

  const { id } = req.params;

  const {
    workout,
    duration,
    calories,
    date,
  } = req.body;

  const sql =
    "UPDATE workouts SET workout=?, duration=?, calories=?, date=? WHERE id=?";

  db.query(
    sql,
    [workout, duration, calories, date, id],
    (err, result) => {

      if (err) {
        res.status(500).send(err);
      } else {
        res.send("Workout Updated");
      }

    }
  );
});

// =========================
// DELETE WORKOUT
// =========================

app.delete("/workouts/:id", (req, res) => {

  const { id } = req.params;

  const sql =
    "DELETE FROM workouts WHERE id=?";

  db.query(sql, [id], (err, result) => {

    if (err) {
      res.status(500).send(err);
    } else {
      res.send("Workout Deleted");
    }

  });
});

// =========================
// ADD WATER INTAKE
// =========================

app.post("/water", (req, res) => {

  const { amount } = req.body;

  const sql =
    "INSERT INTO water_intake (amount) VALUES (?)";

  db.query(sql, [amount], (err, result) => {

    if (err) {
      res.status(500).send(err);
    } else {
      res.send("Water Added");
    }

  });
});

// =========================
// GET WATER TOTAL
// =========================

app.get("/water", (req, res) => {

  const sql =
    "SELECT SUM(amount) AS total FROM water_intake";

  db.query(sql, (err, result) => {

    if (err) {
      res.status(500).send(err);
    } else {
      res.send(result[0]);
    }

  });
});

// =========================
// START SERVER
// =========================

app.listen(5000, () => {
  console.log("Server running on port 5000");
});